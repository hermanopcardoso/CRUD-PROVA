
package DAL;
import java.sql.*;
import javax.swing.JOptionPane;

public class ConectaBd {
      Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
    
    public static Connection conectabd () throws ClassNotFoundException{
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD","postgres","postgres");
            
            return con;
        }
        catch(SQLException error){
        JOptionPane.showMessageDialog(null, error);
        return null;
        }
    }
    
}
